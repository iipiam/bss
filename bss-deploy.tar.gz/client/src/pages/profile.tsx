import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { User, Mail, Phone, CreditCard, Calendar, AlertTriangle, CheckCircle2, XCircle, Shield, FileText, Download } from "lucide-react";
import type { User as UserType, Restaurant, SubscriptionInvoice } from "@shared/schema";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { useLanguage } from "@/contexts/LanguageContext";

type ProfileResponse = {
  user: UserType;
  restaurant: Restaurant;
};

const profileSchema = z.object({
  email: z.string().email("Invalid email address").optional().or(z.literal("")),
  phone: z.string().optional(),
});

type ProfileFormData = z.infer<typeof profileSchema>;

export default function Profile() {
  const { t } = useLanguage();
  const { toast } = useToast();
  const [isEditing, setIsEditing] = useState(false);

  // Fetch user profile
  const { data: profileData, isLoading } = useQuery<ProfileResponse>({
    queryKey: ["/api/profile"],
  });

  const profile = profileData?.user;
  const restaurant = profileData?.restaurant;

  // Fetch subscription invoices
  const { data: invoices = [], isLoading: invoicesLoading } = useQuery<SubscriptionInvoice[]>({
    queryKey: ["/api/subscription-invoices"],
  });

  // Profile update mutation
  const updateProfileMutation = useMutation({
    mutationFn: async (data: ProfileFormData) => {
      return await apiRequest("PUT", "/api/profile", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/profile"] });
      queryClient.invalidateQueries({ queryKey: ["/api/auth/me"] });
      toast({
        title: t.profileUpdated,
        description: t.profileUpdatedDesc,
      });
      setIsEditing(false);
    },
    onError: (error: any) => {
      toast({
        title: t.updateFailed,
        description: error.message || t.updateProfileError,
        variant: "destructive",
      });
    },
  });

  // Cancel subscription mutation
  const cancelSubscriptionMutation = useMutation({
    mutationFn: async () => {
      return await apiRequest("POST", "/api/subscription/cancel", {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/profile"] });
      toast({
        title: t.subscriptionCanceled,
        description: t.subscriptionCancelledDesc,
        variant: "destructive",
      });
    },
    onError: () => {
      toast({
        title: t.cancellationFailed,
        description: t.cancelSubscriptionError,
        variant: "destructive",
      });
    },
  });

  const form = useForm<ProfileFormData>({
    resolver: zodResolver(profileSchema),
    values: {
      email: profile?.email || "",
      phone: profile?.phone || "",
    },
  });

  const onSubmit = (data: ProfileFormData) => {
    updateProfileMutation.mutate(data);
  };

  const handleCancelSubscription = () => {
    cancelSubscriptionMutation.mutate();
  };

  const handleDownloadInvoice = async (invoice: SubscriptionInvoice) => {
    try {
      const filename = `subscription-${invoice.serialNumber}.pdf`;
      const response = await fetch(`/api/subscription-invoices/${filename}`, {
        credentials: 'include',
      });

      if (!response.ok) {
        throw new Error('Failed to download invoice');
      }

      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);

      toast({
        title: t.downloadStarted,
        description: t.downloadingInvoice,
      });
    } catch (error) {
      toast({
        title: t.downloadFailed,
        description: t.downloadInvoiceError,
        variant: "destructive",
      });
    }
  };

  const formatDate = (date: Date | string | null | undefined) => {
    if (!date) return "N/A";
    return new Date(date).toLocaleDateString("en-US", {
      year: "numeric",
      month: "long",
      day: "numeric",
    });
  };

  const formatCurrency = (amount: string | number) => {
    const num = typeof amount === 'string' ? parseFloat(amount) : amount;
    return `${num.toFixed(2)} SAR`;
  };

  const getSubscriptionStatusBadge = (status: string | null | undefined) => {
    switch (status) {
      case "active":
        return (
          <Badge className="bg-green-500/10 text-green-700 dark:text-green-400 border-green-500/20" data-testid="badge-subscription-active">
            <CheckCircle2 className="mr-1 h-3 w-3" />
            {t.active}
          </Badge>
        );
      case "cancelled":
        return (
          <Badge className="bg-red-500/10 text-red-700 dark:text-red-400 border-red-500/20" data-testid="badge-subscription-cancelled">
            <XCircle className="mr-1 h-3 w-3" />
            {t.cancelled}
          </Badge>
        );
      case "expired":
        return (
          <Badge className="bg-orange-500/10 text-orange-700 dark:text-orange-400 border-orange-500/20" data-testid="badge-subscription-expired">
            <AlertTriangle className="mr-1 h-3 w-3" />
            {t.expired}
          </Badge>
        );
      default:
        return (
          <Badge variant="secondary" data-testid="badge-subscription-inactive">
            {t.inactive}
          </Badge>
        );
    }
  };

  if (isLoading) {
    return (
      <div className="container mx-auto p-6 max-w-4xl">
        <div className="space-y-6">
          <div className="h-8 w-48 bg-muted animate-pulse rounded" />
          <div className="grid gap-6 md:grid-cols-2">
            <div className="h-64 bg-muted animate-pulse rounded-lg" />
            <div className="h-64 bg-muted animate-pulse rounded-lg" />
          </div>
        </div>
      </div>
    );
  }

  if (!profile) {
    return (
      <div className="container mx-auto p-6 max-w-4xl">
        <Alert variant="destructive">
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription>{t.failedToLoadProfile}</AlertDescription>
        </Alert>
      </div>
    );
  }

  const isSubscriptionCancelled = restaurant?.subscriptionStatus === "cancelled" || restaurant?.subscriptionStatus === "expired";

  return (
    <div className="container mx-auto p-6 max-w-4xl space-y-6">
      <div>
        <h1 className="text-3xl font-bold" data-testid="text-profile-title">{t.userProfile}</h1>
        <p className="text-muted-foreground">{t.userProfileDesc}</p>
      </div>

      {isSubscriptionCancelled && (
        <Alert variant="destructive" data-testid="alert-subscription-restricted">
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription>
            {t.accountRestrictedDesc}
          </AlertDescription>
        </Alert>
      )}

      <div className="grid gap-6 md:grid-cols-2">
        {/* Profile Information Card */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
            <div>
              <CardTitle className="text-xl">{t.profileInformation}</CardTitle>
              <CardDescription>{t.yourPersonalDetails}</CardDescription>
            </div>
            <User className="h-8 w-8 text-muted-foreground" />
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label className="text-sm font-medium text-muted-foreground">{t.fullName}</Label>
              <p className="text-base font-medium" data-testid="text-fullname">{profile.fullName}</p>
            </div>

            <Separator />

            <div className="space-y-2">
              <Label className="text-sm font-medium text-muted-foreground">{t.username}</Label>
              <p className="text-base font-medium" data-testid="text-username">{profile.username}</p>
            </div>

            <Separator />

            {isEditing ? (
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="email">
                    <Mail className="inline-block mr-2 h-4 w-4" />
                    {t.email}
                  </Label>
                  <Input
                    id="email"
                    type="email"
                    placeholder="your.email@example.com"
                    {...form.register("email")}
                    data-testid="input-email"
                  />
                  {form.formState.errors.email && (
                    <p className="text-sm text-red-500">{form.formState.errors.email.message}</p>
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="phone">
                    <Phone className="inline-block mr-2 h-4 w-4" />
                    {t.phoneNumber}
                  </Label>
                  <Input
                    id="phone"
                    type="tel"
                    placeholder="+966 XX XXX XXXX"
                    {...form.register("phone")}
                    data-testid="input-phone"
                  />
                </div>

                <div className="flex gap-2">
                  <Button
                    type="submit"
                    disabled={updateProfileMutation.isPending}
                    className="flex-1"
                    data-testid="button-save-profile"
                  >
                    {updateProfileMutation.isPending ? t.saving : t.saveChanges}
                  </Button>
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => {
                      setIsEditing(false);
                      form.reset();
                    }}
                    data-testid="button-cancel-edit"
                  >
                    {t.cancel}
                  </Button>
                </div>
              </form>
            ) : (
              <>
                <div className="space-y-2">
                  <Label className="text-sm font-medium text-muted-foreground">
                    <Mail className="inline-block mr-2 h-4 w-4" />
                    {t.email}
                  </Label>
                  <p className="text-base font-medium" data-testid="text-email">{profile.email || t.notSet}</p>
                </div>

                <Separator />

                <div className="space-y-2">
                  <Label className="text-sm font-medium text-muted-foreground">
                    <Phone className="inline-block mr-2 h-4 w-4" />
                    {t.phoneNumber}
                  </Label>
                  <p className="text-base font-medium" data-testid="text-phone">{profile.phone || t.notSet}</p>
                </div>

                <Separator />

                <div className="space-y-2">
                  <Label className="text-sm font-medium text-muted-foreground">
                    <Shield className="inline-block mr-2 h-4 w-4" />
                    {t.role}
                  </Label>
                  <p className="text-base font-medium capitalize" data-testid="text-role">{profile.role || t.employee}</p>
                </div>

                <Button
                  onClick={() => setIsEditing(true)}
                  className="w-full"
                  variant="outline"
                  data-testid="button-edit-profile"
                >
                  {t.editProfile}
                </Button>
              </>
            )}
          </CardContent>
        </Card>

        {/* Subscription Details Card */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
            <div>
              <CardTitle className="text-xl">{t.subscriptionDetails}</CardTitle>
              <CardDescription>{t.subscriptionInformationDesc}</CardDescription>
            </div>
            <CreditCard className="h-8 w-8 text-muted-foreground" />
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label className="text-sm font-medium text-muted-foreground">{t.commercialRegistration}</Label>
              <p className="text-base font-medium" data-testid="text-commercial-registration">
                {restaurant?.commercialRegistration || t.notSet}
              </p>
            </div>

            <Separator />

            <div className="space-y-2">
              <Label className="text-sm font-medium text-muted-foreground">{t.subscriptionPlan}</Label>
              <p className="text-base font-medium capitalize" data-testid="text-subscription-plan">
                {restaurant?.subscriptionPlan || t.none}
              </p>
            </div>

            <Separator />

            <div className="space-y-2">
              <Label className="text-sm font-medium text-muted-foreground">{t.status}</Label>
              <div>{getSubscriptionStatusBadge(restaurant?.subscriptionStatus)}</div>
            </div>

            <Separator />

            <div className="space-y-2">
              <Label className="text-sm font-medium text-muted-foreground">
                <Calendar className="inline-block mr-2 h-4 w-4" />
                {t.startDate}
              </Label>
              <p className="text-base font-medium" data-testid="text-subscription-start">
                {formatDate(restaurant?.subscriptionStartDate)}
              </p>
            </div>

            <Separator />

            <div className="space-y-2">
              <Label className="text-sm font-medium text-muted-foreground">
                <Calendar className="inline-block mr-2 h-4 w-4" />
                {t.endDate}
              </Label>
              <p className="text-base font-medium" data-testid="text-subscription-end">
                {formatDate(restaurant?.subscriptionEndDate)}
              </p>
            </div>

            {restaurant?.subscriptionCancelledAt && (
              <>
                <Separator />
                <div className="space-y-2">
                  <Label className="text-sm font-medium text-muted-foreground">
                    <Calendar className="inline-block mr-2 h-4 w-4" />
                    {t.cancelledOn}
                  </Label>
                  <p className="text-base font-medium text-red-600 dark:text-red-400" data-testid="text-subscription-cancelled">
                    {formatDate(restaurant?.subscriptionCancelledAt)}
                  </p>
                </div>
              </>
            )}

            {restaurant?.subscriptionStatus === "active" && (
              <AlertDialog>
                <AlertDialogTrigger asChild>
                  <Button
                    variant="destructive"
                    className="w-full"
                    data-testid="button-cancel-subscription"
                  >
                    {t.cancelSubscription}
                  </Button>
                </AlertDialogTrigger>
                <AlertDialogContent>
                  <AlertDialogHeader>
                    <AlertDialogTitle>{t.areYouSure}</AlertDialogTitle>
                    <AlertDialogDescription>
                      {t.cancelSubscriptionWarning}{" "}
                      <strong>{formatDate(restaurant?.subscriptionEndDate)}</strong>.
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel data-testid="button-cancel-dialog">{t.keepSubscription}</AlertDialogCancel>
                    <AlertDialogAction
                      onClick={handleCancelSubscription}
                      className="bg-red-600 hover:bg-red-700"
                      data-testid="button-confirm-cancel"
                    >
                      {t.yesCancelSubscription}
                    </AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
            )}
          </CardContent>
        </Card>

        {/* Subscription Invoices Card */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
            <div>
              <CardTitle className="text-xl">{t.subscriptionInvoices}</CardTitle>
              <CardDescription>{t.viewAndDownload}</CardDescription>
            </div>
            <FileText className="h-8 w-8 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            {invoicesLoading ? (
              <p className="text-sm text-muted-foreground">{t.loadingInvoices}</p>
            ) : invoices.length === 0 ? (
              <p className="text-sm text-muted-foreground">{t.noInvoices}</p>
            ) : (
              <div className="space-y-3">
                {invoices.map((invoice) => (
                  <div
                    key={invoice.id}
                    className="flex items-center justify-between p-4 border rounded-lg hover-elevate"
                    data-testid={`card-invoice-${invoice.serialNumber}`}
                  >
                    <div className="space-y-1 flex-1">
                      <div className="flex items-center gap-2">
                        <p className="text-sm font-medium" data-testid={`text-invoice-number-${invoice.serialNumber}`}>
                          {t.invoice} #{invoice.serialNumber}
                        </p>
                        <Badge variant="outline" className="capitalize" data-testid={`badge-invoice-plan-${invoice.serialNumber}`}>
                          {invoice.subscriptionPlan}
                        </Badge>
                      </div>
                      <p className="text-xs text-muted-foreground" data-testid={`text-invoice-date-${invoice.serialNumber}`}>
                        {formatDate(invoice.invoiceDate)}
                      </p>
                      <p className="text-sm font-semibold text-primary" data-testid={`text-invoice-total-${invoice.serialNumber}`}>
                        {formatCurrency(invoice.total)}
                      </p>
                    </div>
                    <Button
                      onClick={() => handleDownloadInvoice(invoice)}
                      variant="outline"
                      size="sm"
                      data-testid={`button-download-invoice-${invoice.serialNumber}`}
                    >
                      <Download className="h-4 w-4 mr-2" />
                      {t.download}
                    </Button>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
